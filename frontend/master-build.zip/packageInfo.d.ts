export declare const packageInfo: {
    name: string;
    path: string;
    type: string;
    version: string;
};
